---
title: Introduction to views
description: Learn how to define views and respond to HTTP requests.
sidebar_label: Introduction
---
