---
title: Release notes
description: Find all the release notes of the Marten web framework.
pagination_next: null
---

Here are listed the release notes for each version of the Marten web framework.

## Marten 0.2

* [Marten 0.2 release notes](./release-notes/0.2)

## Marten 0.1

* [Marten 0.1.5 release notes](./release-notes/0.1.5)
* [Marten 0.1.4 release notes](./release-notes/0.1.4)
* [Marten 0.1.3 release notes](./release-notes/0.1.3)
* [Marten 0.1.2 release notes](./release-notes/0.1.2)
* [Marten 0.1.1 release notes](./release-notes/0.1.1)
* [Marten 0.1 release notes](./release-notes/0.1)
