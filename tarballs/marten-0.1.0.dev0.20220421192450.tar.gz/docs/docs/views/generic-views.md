---
title: Generic views
description: Learn how to leverage generic views to perform common tasks.
sidebar_label: Generic views
---
