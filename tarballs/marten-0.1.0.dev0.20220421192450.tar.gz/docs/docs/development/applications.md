---
title: Applications
description: Learn how to leverage applications to structure your projects.
sidebar_label: Applications
---
