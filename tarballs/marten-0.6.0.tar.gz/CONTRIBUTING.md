# Contributing to Marten

> **Warning**
> If you've found a security issue, please **do not open a GitHub issue** and refer to our [security guidelines](https://martenframework.com/docs/the-marten-project/contributing#about-security-issues) instead.

Thank you for contributing to the Marten web framework! A list of simple rules is available on the online
documentation to help you contribute to this project: https://martenframework.com/docs/the-marten-project/contributing
