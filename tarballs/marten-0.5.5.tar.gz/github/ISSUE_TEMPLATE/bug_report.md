---
name: Bug report
about: Create an issue to report a bug or something that is not working as expected.
title: ''
labels: Bug
assignees: ''
---

<!--
Thanks for taking the time to report issues with the Marten framework!

Don't forget to include as many details as possible in your ticket: an explanatory description of the issue at hand and how to reproduce it, snippets and/or tracebacks if this is appropriate, etc.
-->
