---
slug: /
---

# Prologue

**Marten** is a Crystal Web framework that enables pragmatic development and rapid prototyping. It provides a consistent and extensible set of tools that developers can leverage to build web applications without reinventing the wheel.

## Getting started

## Browsing the documentation
