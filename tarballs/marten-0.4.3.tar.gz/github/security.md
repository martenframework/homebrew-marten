# Security policy

If you've found a security issue or vulnerability in Marten, please **do not open a GitHub issue**. Instead, refer to our [security guidelines](https://martenframework.com/docs/the-marten-project/contributing#about-security-issues) to learn how to report it.
