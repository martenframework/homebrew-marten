---
title: Model callbacks
description: Learn how to define model callbacks.
sidebar_label: Callbacks
---
