---
title: Introduction to schemas
description: Learn how to define schemas and use them in views.
sidebar_label: Introduction
---
