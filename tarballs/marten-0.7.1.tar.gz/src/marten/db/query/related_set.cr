require "./set"

module Marten
  module DB
    module Query
      # Represents a query set resulting from a many-to-one relation.
      class RelatedSet(M) < Set(M)
        def initialize(
          @instance : Marten::DB::Model,
          @related_field_id : String,
          query : SQL::Query(M)? = nil,
          @assign_related : ::Bool = false,
          @prefetched_relations = [] of String,
          @custom_query_sets = {} of String => Set::Any,
        )
          @query = if query.nil?
                     q = SQL::Query(M).new
                     q.add_query_node(effective_query_node)
                     q
                   else
                     query.not_nil!
                   end
        end

        protected def fetch
          super

          @result_cache.not_nil!.each { |r| r.assign_related_object(@instance, @related_field_id) } if assign_related?
        end

        protected def build_record(**kwargs)
          record = M.new(**kwargs)
          record.assign_related_object(@instance, @related_field_id)
          record
        end

        protected def clone(other_query = nil)
          RelatedSet(M).new(
            instance: @instance,
            related_field_id: @related_field_id,
            query: other_query.nil? ? @query.clone : other_query.not_nil!,
            assign_related: @assign_related,
            prefetched_relations: prefetched_relations,
            custom_query_sets: custom_query_sets,
          )
        end

        private def effective_query_node
          field = M.get_field(@related_field_id)
          if field.is_a?(Field::Polymorphic)
            Node.new({field.id_field_id => @instance.pk, field.type_field_id => @instance.class.name})
          else
            Node.new({@related_field_id => @instance.pk})
          end
        end

        private getter? assign_related
      end
    end
  end
end
