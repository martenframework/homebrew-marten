module Marten
  module DB
    module Query
      module SQL
        module Annotation
          class Sum < Base
            def from_db_result_set(result_set : ::DB::ResultSet)
              if field.is_a?(Field::BigInt) || field.is_a?(Field::Decimal)
                result_set.read(BigDecimal?)
              else
                result_set.read(Int64 | Int32 | Int16 | Int8 | Float64 | Float32 | Nil)
              end
            end

            def to_sql(with_alias : Bool = true) : String
              sql_part = if distinct?
                           "SUM(DISTINCT #{alias_prefix}.#{field.db_column})"
                         else
                           "SUM(#{alias_prefix}.#{field.db_column})"
                         end

              with_alias ? "#{sql_part} as #{alias_name}" : sql_part
            end
          end
        end
      end
    end
  end
end
