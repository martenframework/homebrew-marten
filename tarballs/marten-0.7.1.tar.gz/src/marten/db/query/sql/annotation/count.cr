module Marten
  module DB
    module Query
      module SQL
        module Annotation
          class Count < Base
            def from_db_result_set(result_set : ::DB::ResultSet)
              result_set.read(Int64 | Int32 | Int16 | Int8 | Nil)
            end

            def to_sql(with_alias : Bool = true) : String
              sql_part = if distinct?
                           "COUNT(DISTINCT #{alias_prefix}.#{field.db_column})"
                         else
                           "COUNT(#{alias_prefix}.#{field.db_column})"
                         end

              with_alias ? "#{sql_part} as #{alias_name}" : sql_part
            end
          end
        end
      end
    end
  end
end
