module Marten
  module CLI
    class Manage
      module Command
        class GenMigrations < Base
          command_name :genmigrations
          help "Generate new database migrations."

          @app_label : String?
          @check : Bool = false
          @create_empty : Bool = false
          @dry_run : Bool = false
          @no_header : Bool = false

          def setup
            on_argument(:app_label, "The name of an application to generate migrations for") { |v| @app_label = v }

            on_option(
              "dry-run",
              "Shows migrations that would be generated without writing them"
            ) do
              @dry_run = true
            end

            on_option(
              :check,
              "Exits with a non-zero status if model changes require migrations without generating them"
            ) do
              @check = true
            end

            on_option("empty", "Create an empty migration") { @create_empty = true }

            on_option(
              "no-header",
              "Do not add header comments at the top of newly generated migration files"
            ) do
              @no_header = true
            end
          end

          def run
            app_config = app_label.nil? ? nil : Marten.apps.get(app_label.not_nil!)

            if create_empty?
              if app_config.nil?
                print("An application label must be specified when using --empty")
                return
              end

              changes = gen_empty_migration_changes(app_config.not_nil!)
            else
              diff = DB::Management::Migrations::Diff.new
              changes = app_config.nil? ? diff.detect : diff.detect([app_config])
            end

            if check?
              show_migrations(changes) if dry_run? && !changes.empty?
              do_exit(changes.empty? ? 0 : 1)
            elsif changes.empty?
              print("No changes detected")
            elsif dry_run?
              show_migrations(changes)
            else
              write_migrations(changes)
            end
          rescue e : Apps::Errors::AppNotFound
            print_error(e.message)
          end

          private getter app_label

          private getter? check
          private getter? dry_run
          private getter? no_header

          private def create_empty?
            @create_empty
          end

          private def gen_empty_migration_changes(app_config)
            reader = DB::Management::Migrations::Reader.new
            latest_migration_klass = reader.latest_migration(app_config.not_nil!)

            dependencies = Array(Tuple(String, String)).new
            if !latest_migration_klass.nil?
              dependencies << {app_config.label, latest_migration_klass.not_nil!.migration_name}
            end

            {
              app_config.label => [
                DB::Management::Migrations::Diff::Migration.new(
                  app_label: app_config.label,
                  name: "#{Time.local.to_s("%Y%m%d%H%M%S")}1",
                  operations: Array(DB::Migration::Operation::Base).new,
                  dependencies: dependencies
                ),
              ],
            }
          end

          private def show_migrations(changes)
            changes.each do |app_label, migrations|
              print(style("Planned migrations for app '#{app_label}':", fore: :light_blue, mode: :bold))
              app_config = Marten.apps.get(app_label)

              migrations.each do |migration|
                migration_filepath = app_config.migrations_path.join("#{migration.name}.cr")

                print(
                  "  › Would create [#{style(migration_filepath.to_s.gsub("#{Dir.current}/", ""), mode: :dim)}]"
                )

                migration.operations.each do |op|
                  print("      ○ #{op.describe}")
                end
              end
            end
          end

          private def write_migrations(changes)
            changes.each do |app_label, migrations|
              print(style("Generating migrations for app '#{app_label}':", fore: :light_blue, mode: :bold))
              app_config = Marten.apps.get(app_label)
              migrations.each do |migration|
                migration_filepath = app_config.migrations_path.join("#{migration.name}.cr")

                print(
                  "  › Creating [#{style(migration_filepath.to_s.gsub("#{Dir.current}/", ""), mode: :dim)}]...",
                  ending: ""
                )

                Dir.mkdir(app_config.migrations_path) unless Dir.exists?(app_config.migrations_path)
                File.write(migration_filepath, migration.serialize(no_header: no_header?))

                print(style(" DONE", fore: :light_green, mode: :bold))

                migration.operations.each do |op|
                  print("      ○ #{op.describe}")
                end
              end
            end
          end
        end
      end
    end
  end
end
