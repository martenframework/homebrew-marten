---
slug: /
---

# Prologue

**Marten** is a Crystal Web framework that enables pragmatic development and rapid prototyping. It provides a consistent and extensible set of tools that developers can leverage to build web applications without reinventing the wheel.

## Getting started

Are you new to the Marten web framework? The following resources will help you get started:

* The [installation guide](./getting-started/installation.md) will help you install Crystal and the Marten CLI
* The [tutorial](./getting-started/tutorial.md) will help you discover the main features of the framework by creating a simple web application

## Browsing the documentation

The Marten documentation contains multiple pages and references that don't necessarilly serve the same purpose. In order to help you browse this documentation, here is an overview of the different sorts of contents you might encounter:

* **Topic-specific guides** discuss the key concepts of the framework. They provide explanations and useful information around things like [models](./models-and-databases), [handlers](./handlers-and-http), and [templates](./templates)
* **Reference pages** provide a curated technical reference of the framework APIs
* **How-to guides** document how to solve common problems whem working with the framework. Those can cover things like deployments, app development, etc

Additionally, an automatically-generated [API reference](pathname:///api/index.html) is also available in order to dig into Marten's internals.
