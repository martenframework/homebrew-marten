---
title: Introduction to internationalization
description: Learn how to leverage translations and localized contents in your Marten projects.
sidebar_label: Introduction
---
