---
title: Asset handling
description: Learn how to handle assets.
sidebar_label: Asset handling
---
