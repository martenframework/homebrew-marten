---
title: Uploading files
description: Learn how to upload files.
sidebar_label: Uploading files
---
