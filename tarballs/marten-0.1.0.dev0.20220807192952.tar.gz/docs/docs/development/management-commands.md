---
title: Management commands
description: Learn the basics of the Marten management CLI tool.
sidebar_label: Management commands
---
