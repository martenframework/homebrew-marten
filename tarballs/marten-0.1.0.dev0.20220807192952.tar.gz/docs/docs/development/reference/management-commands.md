---
title: Management commands
description: Management commands reference.
---

## `collectassets`

## `genmigrations`

## `init`

## `listmigrations`

## `migrate`

## `resetmigrations`

## `routes`

## `serve`

## `version`
