---
title: Templates
description: Learn how to write templates and generate HTML dynamically.
sidebar_label: Introduction
---

