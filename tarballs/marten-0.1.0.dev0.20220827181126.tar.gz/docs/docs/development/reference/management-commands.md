---
title: Management commands
description: Management commands reference.
---

## `collectassets`

## `genmigrations`

## `listmigrations`

## `migrate`

## `new`

## `resetmigrations`

## `routes`

## `serve`

## `version`
