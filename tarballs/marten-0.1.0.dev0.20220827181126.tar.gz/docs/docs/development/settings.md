---
title: Settings
description: Learn the basics of Marten settings.
sidebar_label: Settings
---
