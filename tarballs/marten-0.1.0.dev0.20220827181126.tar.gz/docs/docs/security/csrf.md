---
title: Cross-Site Request Forgery protection
description: Learn about Cross-Site Request Forgeries (CSRF) attacks and how to protect your application from them.
sidebar_label: CSRF protection
---
